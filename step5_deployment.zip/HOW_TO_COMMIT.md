# Committing Steps 3, 4 and 5

Each folder holds one step's files at the same paths as in the repo. Commit them **in order**: step 3, then 4, then 5. Each step builds on the one before it, so each teammate pulls first.

## Steps (each teammate)
```bash
gh repo clone prxneel007/pathsnap-map-matching      # first time only; the repo is private, so ask to be added as a collaborator
cd pathsnap-map-matching
git pull                                 # get the previous step
cp -R /path/to/unzipped/step3_models/. .   # or step4_hmm/. or step5_deployment/.
git add -A
git commit -m "Step 3: model comparison (6 models) and Bayesian tuning with Optuna"
git push
```

Commit messages:
- **step3_models**: `Step 3: model comparison (6 models) and Bayesian tuning with Optuna`
- **step4_hmm**: `Step 4: HMM + Viterbi route reconstruction and decoder tuning`
- **step5_deployment**: `Step 5: FastAPI backend, Streamlit UI, deployment README`

## What each step contains
| Folder | Files |
|---|---|
| step3_models | `src/models.py`, `src/metrics.py`, `notebooks/03_models.ipynb`, `notebooks/04_bayes_opt.ipynb`, `outputs/models/`, `outputs/tuning/`, `artifacts/model.joblib`, `artifacts/model_config.json` |
| step4_hmm | `src/hmm.py`, `notebooks/05_hmm.ipynb`, `tests/test_hmm.py`, `outputs/hmm/`, `artifacts/hmm_config.json` |
| step5_deployment | `src/pipeline.py`, `api/main.py`, `ui/app.py`, `ui/requirements.txt`, `README.md` (replaces the Steps 1-2 README) |

Before committing, set your own git name and email: `git config user.name "..."` and `git config user.email "..."`.
